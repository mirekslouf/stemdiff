# STEMDIFF :: package for simple processing of 4D-STEM data

* The STEMDIFF package converts... <br>
  ... a 4D-STEM dataset from a SEM microscope (huge and complex) <br>
  ... to a powder-like 1D diffraction pattern (simple and easy to work with).
* The package is a key part of our 4D-STEM/PNBD method, <br>
  which was described in two publications:
	- publication 1: XXX
	- publication 2: in preparation.

[doplnit obrazek: 4D-dataset -> 2D-diffractogram -> 1D-diffractogram]

## Printscreen from a typical STEMDIFF session

* The 4D-STEM/PNBD method and STEMDIFF package were developed
  in order to be as simple as possible.
* In principle it is enough to measure 4D-STEM data,
  install the STEMDIFF package and run the script/template below.

## Typical usage of STEMDIFF package

1. You modify and run a single script/template (printscreen above), <br>
   which employes the functions of *stemdiff* package functions to:
	* read the 4D-STEM dataset
	* combine the 4D datafiles into a 2D diffraction pattern
	* convert the 2D diffractogram to a 1D radially averaged diffractogram.
2. A few notes:
	* We note that STEMDIFF package uses Spyder as a simple user interface.
	* This enables to see both the input script and the output text + graphs.
	* The resulting 1D-diffractogram is processable by arbitrary diffraction SW.
3. More detailed documentation:
	* The method explanation + examples are in the above-listed publications.
	* The user guide and technical details are available at readthedocs.org

## Brief history of STEMDIFF package

* Version 1.0 = Matlab: just simple summation of 4D-dataset
* Version 2.0 = like v1.0 + post-processing in Jupyter
* Version 3.0 = Python scripts: summation + S-filtering
* Version 4.0 = Python package: summation + S-filtering + deconvolution
	- summation = summation of all 2D-diffractograms
	- S-filtering = sum only diffractograms with strong diffractions = high S
	- deconvolution = reduce the effect of primary beam spread
      &rarr; better resolution 
* Version 4.2 = like v4.0 + a few important improvements, such as:
	- sum just the central region with the strongest diffractions - higher speed
	- 3 centering types: (0) geometry, (1) weight of 1st, (2) individual weights 
	- better definition of summation and centering parameters
	- improved master script/teplate + better documentation strings
