'''
stemdiff.const
    Constants that are used within package stemdiff.
'''

# Key constants
# (these costants are not expected to change for given microscope
# (they can be adjusted if the program is used for a different microscope
# DET_SIZE = size of detector (in pixels)
# RESCALE = scaling coefficient: final image size = DET_SIZE * RESCALE

DET_SIZE = 256
RESCALE  = 4

# Additional settings
# (these settings/objects must be adjusted according to experimental conditions
# (typically, the objects are defined at the beginning of the main program
# centering = parameters for the determination of the center of 2D-STEM images
# summation = parameters for the summation of 2D-STEM images

class centering:
    '''
    Set parameters for determination of center of 2D-STEM images.
    
    Typical usage
    -------------
        import stemdiff.const
        CENTERING = stemdiff.const.centering(ctype=1,csquare=30,cintensity=.8)
    
    More help & description of parameters
    -------------------------------------
        import stemdiff.const
        help(stemdiff.const.centering)
    '''
    
    def __init__(self, ctype=1, csquare=None, cintensity=None):
        '''
        Initialize parameters for center determination.

        Parameters
        ----------
        ctype : integer (values: 0, 1, 2)
            0 => intensity center not determined, geometrical center is used;
            1 => center determined from the first image and kept constant;
            2 => center is determined for each individual image.
        csquare : integer (interval: 10--DET_SIZE)
            Size of the central square (in pixels),
            within which the center of intensity is determined.
        cintensity : float (interval: 0--1)
            Intensity fraction, which is used for center determination.
            Example: cintensity = 0.9 => only intensities > 0.9 of ma

        Returns
        -------
        Centering object.
        '''
        self.ctype = ctype
        self.csquare = csquare
        self.cintensity = cintensity
        
class summation:
    '''
    Set parameters for summation of 2D-STEM images.
    
    Typical usage
    -------------
        import stemdiff.const
        SUMMATION = stemdiff.const.summation(psfsize=95,imgsize=90,iterate=30)
        
    More help & description of parameters
    -------------------------------------
        import stemdiff.const
        help(stemdiff.const.summation)
    '''

    def __init__(self, psfsize=None, imgsize=None, iterate=None):
        '''
        Initialize parameters for summation.

        Parameters
        ----------
        psfize : integer (interval: something--DET_SIZE)
            Size/edge of central square, from which 2D-PSF will be determined.
        imgsize : integer (interval: something --DET_SIZE)
            Size of array read from the detector is reduced to imgsize.
            If given, we sum only the central square with size = imgsize.
            Smaller area = higher speed; outer area = just weak diffractions.   
        iterate : integer  
            Number of iterations during R-L deconvolution.

        Returns
        -------
        Summation object.
        '''
        self.psfsize = psfsize
        self.imgsize = imgsize
        self.iterate = iterate
