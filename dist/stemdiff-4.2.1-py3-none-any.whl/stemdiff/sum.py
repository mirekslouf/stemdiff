'''
stemdiff.sum
    Sum 4D-STEM datafiles to create one powder diffraction file.
    The module contains functions for several types of summation.
'''

import numpy as np
import stemdiff.io
import stemdiff.dbase
import stemdiff.radial
from stemdiff.const import DET_SIZE, RESCALE
from skimage import transform, restoration

def sum_all(DBASE,SUMMATION,R=RESCALE):
    '''
    Sum all datafiles from pixelated detector.
    For explanation of parameters, see function sum_2D_stem_files.
    '''
    all_datafiles = stemdiff.dbase.get_all_datafiles(DBASE)
    arr = stemdiff.sum.sum_2Dstem_files(
        all_datafiles, R=R, imgsize=SUMMATION.imgsize)
    return(arr)

def sum_highS(DBASE,SUMMATION,R=RESCALE, S=None, P=None, N=None):
    '''
    Sum datafiles from pixelated detector with high S (Shannon entropy).
    For explanation of parameters, see function sum_2D_stem_files.
    '''
    highS_datafiles = stemdiff.dbase.get_high_S_files(DBASE, P=P, N=N, S=S)
    arr = stemdiff.sum.sum_2Dstem_files(
        highS_datafiles, R=R, imgsize=SUMMATION.imgsize)
    return(arr)

def sum_highS_deconv(DBASE,SUMMATION,PSF,R=RESCALE, S=None, P=None, N=None):
    '''
    Sum datafiles from pixelated detector with high S and PSF deconvolution.
    For explanation of parameters, see function sum_2D_stem_files.
    '''
    highS_datafiles = stemdiff.dbase.get_high_S_files(
        DBASE, P=P, S=S, N=N)
    arr = stemdiff.sum.sum_2Dstem_files(
        highS_datafiles, R, PSF,
        itr=SUMMATION.iterate, imgsize=SUMMATION.imgsize)
    return(arr)

def sum_2Dstem_files(df,R=RESCALE, PSF=None, itr=None, imgsize=None):
    '''
    Sum all input datafiles from 2D-STEM pixelated detector.
    This function can be called directly, but typically it is called
    from functions sum_all, sum_highS, and sum_highS_deconv defined above.
    
    Parameters
    ----------
    df: pandas DataFrame row iterator
        DataFrame columns: DatafileName,Entropy,Xcenter,Ycenter.
    R : integer
        Rescale coefficient;
        the size of the final array is rescaled/multiplied by factor R.
        If PSF is given, the rescaling is performed before deconvolution.
        Note: PSF should the same rescale coefficient as given here!
    PSF : 2D numpy array
        PSF = point spread function for deconvolution
    itr : integer 
        Number of iterations during R-L deconvolution
    imgsize: integer
        Size of array read from the detector is reduced to imgsize.
        If imgsize is given, we sum only the central square with edge=imgsize.
        Smaller central area gives higher speed during deconvolution,
        while the outer area usually contains just the weakest diffractions.
        
    Returns
    -------
    2D numpy array
        The array is a sum of datafiles;
        if the datafiles are pre-filtered, we get sum of filtered datafiles,
        if PSF is given, we get sum of datafiles with PSF deconvolution.
    '''
    # Prepare variables ......................................................
    n = 0
    if imgsize:
        arr_size = imgsize
        xc,yc = (None,None)
    else:
        arr_size = DET_SIZE
    # Sum without deconvolution ..............................................
    if type(PSF)==type(None):
        # Prepare files
        # (arr size = detector size => rescaling at the end - see below
        sum_arr   = np.zeros((arr_size,arr_size), dtype=np.float)
        final_arr = np.zeros((arr_size,arr_size), dtype=np.uint16)
        # Sum datafiles
        # (rescaling can be done AFTER summation if there is no deconvolution
        for index,datafile in df:
            arr = stemdiff.io.read_datafile(datafile.DatafileName)
            # If rsize was given, reduce array size
            if imgsize:
                xc,yc = (round(datafile.Xcenter/R),round(datafile.Ycenter/R))
                arr = stemdiff.io.reduce_array_size(arr,imgsize,xc,yc)
            sum_arr += arr
            n += 1
        # Rescale final datafile
        norm_const = np.max(sum_arr)
        sum_arr = transform.rescale(sum_arr, R, order=3)
        sum_arr = sum_arr/np.max(sum_arr) * norm_const
    # Sum with deconvolution .................................................
    else:
        # Read PSF and normalize it
        # (normalization of PSF is necessary for deconvolution algorithm
        psf = stemdiff.psf.read_psf(PSF)
        psf = psf/np.sum(psf)
        # Prepare files
        # (array size = detector size * R => rescaling during summation
        # (if imsize was given, detector size is reduced to imsize
        sum_arr   = np.zeros((arr_size*R,arr_size*R), dtype=np.float)
        final_arr = np.zeros((arr_size*R,arr_size*R), dtype=np.uint16)
        # Sum datafiles with rescaling and deconvolution
        # (rescaling must be done during summagion BEFORE deconvolution
        for index,datafile in df:
            print('.',end='')
            arr = stemdiff.io.read_datafile(datafile.DatafileName)
            # Rescale array
            # (rescaling is done before reducing detector/array size
            # (this should result in more precise center determination
            arr = stemdiff.io.rescale_array(arr, R)
            # If rsize parameter was given, reduce detector area
            if imgsize:
                xc,yc = (round(datafile.Xcenter),round(datafile.Ycenter))
                arr = stemdiff.io.reduce_array_size(arr,imgsize*R,xc,yc)
            # Normalize array
            # (normalization must be done before deconvolution
            # (BUT we save norm.const to restore orig.intensity at the end            
            norm_const = np.max(arr)
            arr = arr/np.max(arr)
            # Deconvolution
            arr = restoration.richardson_lucy(arr, psf, iterations=itr)
            # Multiply by the saved normalization constant
            arr = arr * norm_const
            # Add rescaled and deconvoluted file to summation
            sum_arr += arr
            n += 1
        print()
    # Calculate final array ..................................................
    # (divide sum by number of summed files in order to get reasonable values
    final_arr = np.round(sum_arr/n).astype(np.uint16)
    # Return final array
    return(final_arr)

def save_results(arr, output, icut=300, itype='8bit', rdist=True):
    '''
    Save results of summation (final 2D-image + optional 1D-radial profile).

    Parameters
    ----------
    arr : 2D numpy array
        Array representing final 2D-diffractogram.
    output : string
        Filename of output 2D-diffratogram
        (and 1D-radial distribution, which is calculated if rdist=True);
        name of 2D-diffractogram will be [output.png],
        name of 1D-radial distribution will be [output.txt].
    icut : integer
        Cut of intensity;
        if icut = 300, all image intensities > 300 will be equal to 300.
    itype: string ('8bit'  or '16bit')
        Type of the image: 8 or 16 bit grayscale   
    rdist : boolean
        If rdist=True, calculate and save also 1D-radial distribution.
        Name of the saved file: [output.txt] => see output argument above.
        
    Returns
    -------
    None.
    '''
    # Prepare filenames
    output_2d_image   = output + '.png'
    output_1d_profile = output + '.txt'
    # a) Save summation = 2D-array as image
    stemdiff.io.save_array(arr, output_2d_image, icut, itype)
    # b) Calculate and save 1D-radial profile of the image
    if rdist:
        stemdiff.radial.save_radial_distribution(arr, output_1d_profile)
