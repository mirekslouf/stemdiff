'''
stemdiff.psf
    Calculate PSF function from 4D-STEM datafiles.
    The PSF (point spread function) is used for summation with deconvolution.
'''

import numpy as np
import matplotlib.pyplot as plt
import stemdiff.io, stemdiff.dbase
from stemdiff.const import DET_SIZE, RESCALE

def psf_from_lowS_files(
        DBASE,SUMMATION,R=RESCALE,S=None,P=None,N=None):
    '''
    Extract 2D-PSF from datafiles with low Shannon entropy S.
    PSF = point-spread function is taken from central region ~ cental spot.
    
    Parameters
    ----------
    DBASE: string or pathlib object
        Filename of database containing
        names of all datafiles and their Shannon entropy values.
    SUMMATION: summation object
        Summation parameters; here we need the size/edge
        of the central square, from which 2D-PSF will be determined.
    R: integer
        Rescale coefficient;
        PSF function is rescaled/enlarged R-times.
        Typical values of R are 2 or 4; default is stemdiff.const.RESCALE.
    S: float
        Shannon entropy value;
        If S is given, PSF will be extracted only from files with entropy < S.
    P: float
        Percent of files with lowest entropy;
        if P is given, PSF will be extracted only from those files.
    N: integer
        Number of files with lowest entropy;
        if N is given, PSF will be extracted only from those files.
    
    Returns:
    --------
    2D numpy array
        The array reprsents experimental PSF;
        it is a sum of central areas/spots of input datafiles
        (divided by number of summed datafiles to get reasonable scale).
        
    Note:
    -----
    Priority of parameters: S > P > N
        i.e. if S is given, P and N are ignored etc.
    '''
    # Get filenames with low entropy values
    lowS_datafiles = stemdiff.dbase.get_low_S_files(DBASE, S=S, P=P, N=N)
    # Get PSF function
    psf = psf_from_datafiles(lowS_datafiles,SUMMATION, R=R)
    return(psf)

def psf_from_datafiles(df,SUMMATION,R=RESCALE):
    '''
    Parameters
    ----------
    df: pandas DataFrame row iterator
        DataFrame columns: DatafileName,Entropy,Xcenter,Ycenter.
    SUMMATION: summation object
        Summation parameters; here we need the SUMMATION.psfsize
        = edge of the central square, from which 2D-PSF will be determined.
        If SUMMATION.psfsize is not given => take PSF from the whole array.
    R: integer
        Rescale coefficient;
        PSF function is rescaled/enlarged R-times.
        Typical values of R are 2 or 4; default is stemdiff.const.RESCALE.
   
    Returns
    -------
    2D numpy array
        The array represents experimental PSF;
        it is a sum of central areas/spots of input datafiles
        (divided by number of summed datafiles to get reasonable scale).
    '''
    # Prepare variables
    # a) number of datafilesr
    n = 0
    # b) array for PSF
    psf = np.zeros((DET_SIZE*R,DET_SIZE*R), dtype=np.float)
    if SUMMATION.psfsize:
        # If SUMMATION.psfsize is defined => reduce array dimension
        rsize = SUMMATION.psfsize * R
        xc,yc = ( (DET_SIZE*R)//2, (DET_SIZE*R)//2 )
        psf = stemdiff.io.reduce_array_size(psf,rsize,xc,yc)    
    # Go through the files...
    for index,datafile in df:
        n += 1
        arr = stemdiff.io.read_datafile(datafile.DatafileName)
        # ..rescale array
        arr = stemdiff.io.rescale_array(arr, R)
        if SUMMATION.psfsize:
            # ...read coordinates of the center
            xc,yc = (round(datafile.Xcenter),round(datafile.Ycenter))
            # ..cut central square (the area containing central spot)    
            arr = stemdiff.io.reduce_array_size(arr,rsize,xc,yc)
        psf += arr
    # Calculate final experimental PSF
    # (divide sum by number of summed files in order to get reasonable values
    psf = np.round(psf/n).astype(np.uint16)
    # Convert square mask to round mask ~ set corners to zero
    # psfsize = SUMMATION.psfsize
    # xc,yc   = (psfsize/2, psfsize/2) 
    # for x in range(psfsize):
    #     for y in range(psfsize):
    #         r = np.sqrt((x-xc)**2 + (y-yc)**2)
    #         if r > psfsize/2: psf[x,y] = 0
    # Return final array
    return(psf)

def save_psf(arr, output_file):
    np.save(output_file, arr)

def read_psf(input_file):
    arr = np.load(input_file, allow_pickle=True)
    return(arr)

def plot_psf(arr, plt_type='2D', plt_size=None, output=None):
    '''
    Show plot of PSF function.
    
    Parameters
    ----------
    arr: 2D numpy array
        2D-array representing the 2D-PSF function.
    plt_type: string
        Either '2D' or '3D' - type of the plot.
    plt_size: integer
        Size of the plot:
        the function plots only the central square with size = plt_size
        or the whole 2D-array if parameter plt_size is not given.        
        
    Returns
    -------
    This function does not have a return value.
    It just shows the plot of given array in 2D or 3D.
    '''
    # Copy of arr variable
    # (in order not to change original array during (possible) resizing
    arr2 = arr.copy()
    # Prepare variables
    Xsize,Ysize = arr.shape
    xc,yc = (int(Xsize/2),int(Ysize/2))
    # Reduce array size for plotting, if required
    # (here we work with the array copy so as not to change to original
    if plt_size:
        arr2 = stemdiff.io.reduce_array_size(arr2,plt_size,xc,yc)
    if plt_type=='2D':
        plt.imshow(arr2)
        plt.colorbar()
    else:
        # Prepare meshgrid for 3D-plotting
        Xsize,Ysize = arr2.shape
        Xhalf,Yhalf = int(Xsize/2),int(Ysize/2)
        X = np.linspace(-Xhalf,Xhalf, num=Xsize, endpoint=True)
        Y = np.linspace(-Yhalf,Yhalf, num=Ysize, endpoint=True)
        Xm,Ym = np.meshgrid(X,Y)
        # Create 3D-plot
        from mpl_toolkits.mplot3d import Axes3D
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        ax.plot_surface(
            Xm,Ym,arr2, cmap='coolwarm', linewidth=0, antialiased=False)
        # The following command can be activated if you need defined Z-scale
        # ax.set_zlim(0,12000)
        plt.tight_layout()
    # Final output: show the plot (and save it, if it was requested)
    if output == None:
    # (if argument [output] was not given => just show the plot
        plt.show()
    else:
    # (if argument [output] was given => save the plot and then show it
    # (it must be done in this order - because plt.show() clears the plot!
        plt.savefig(output, dpi=300)
        plt.show()