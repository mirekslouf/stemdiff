# Python package initialization file.

'''
STEMDIFF package
    convert 4D-STEM datacube to powder diffraction pattern
'''

__version__ = '4.2.1'


