Test & demo of package STEMDIFF
===============================

This directory should contain three files from stemdiff/src/data:
-----------------------------------------------------------------
00_readme.txt       = this file
01_download_data.py = script that downloads simple test data from www
02_stemdiff_run.py  = master script, which performs complete data processing

How to test the stemdiff calculations:
--------------------------------------
0) Open Spyder (if not installed -> pip install spyder).
   Package STEMDIFF uses freeware Spyder IDE as UI (user interface).
   Spyder shows the running program and its text/graphical outputs consistently.
1) In Spyder, open and run script: 01_download_data.py
   This script should download testing data from www to subdirectory DATA.
   Wait until the download is complete (be patient; size of the data > 5 MB).
2) In Spyder, open and run script: 02_stemdiff_run.py
   This script performs all STEMDIFF calculations.
   The outputs (2D and 1D diffractograms) are saved in current directory.
   The script can be used as a template for your calculations in future.